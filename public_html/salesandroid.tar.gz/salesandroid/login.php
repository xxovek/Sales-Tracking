<?php

require "conn.php";
$user_name = $_POST["username"];
$user_pass = $_POST["password"];
//$user_name = 'vikas123';
//$user_pass = 'vikas';
$array = [];
$row = [];
$mysql_qry = "select * from SalesManMaster where email like '$user_name' and spassword like '$user_pass';";
$result = mysqli_query($conn ,$mysql_qry);

if(mysqli_num_rows($result) > 0)
{
	$row=mysqli_fetch_row($result);

	$myArr = array($row[0],$row[4],$row[5]);

	exit(json_encode($myArr));
   	// print_r($myJSON);

  	mysqli_free_result($result);


}
else
{
	//print_r("INVALID USERNAME AND PASSWORD");
	$result = null;

}

?>

<?php

require "conn.php";

$lan = $_POST["lan"];
$lon = $_POST["lon"];
$uid = $_POST["uid"];
$shopid = $_POST["shopid"];;


$mysql_qry1 = "SELECT * FROM salesManAssignTransaction WHERE salesAssignId = '$uid' and shopid ='$shopid' AND  DATE_FORMAT(created_at,'%Y-%m-%d') = CURRENT_DATE";

$result1 = mysqli_query($conn ,$mysql_qry1);

if(mysqli_num_rows($result1) > 0){

	$mysql_qry2 = "UPDATE salesManAssignTransaction SET flag=flag+1 WHERE salesAssignId='$uid' and shopid='$shopid'";
	$result1 = mysqli_query($conn ,$mysql_qry2);
	if($conn->query($mysql_qry2) == TRUE)
	{
		print_r ("UPDATE1 SUCCESSFULL");
	}
	else
	{
		print_r ("ERROR: ");
	}

}
else {

	$myArr = [];
	$mysql_qry = "insert into salesManAssignTransaction (salesAssignId,latitude,longitude,shopid) values ('$uid','$lan','$lon','$shopid')";

	$result = mysqli_query($conn ,$mysql_qry);
	if($conn->query($mysql_qry) == TRUE)
	{
		print_r ("INSERT SUCCESSFULL");
	}
	else
	{
		print_r ("ERROR: ");
	}

}

?>
